<form action="http://www.html.am/html-codes/textboxes/submitted.cfm">
<textarea name="myTextBox" cols="100" rows="15" style="background-color:#FCF5D8;color:#AD8C08;">
Enter some text...
</textarea>
<br />
<input type="submit" />
</form>
