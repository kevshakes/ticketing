<form action="http://www.html.am/html-codes/textboxes/submitted.cfm">

<br>
<h1>CHUKA UNIVERSITY SUPPORT PORTAL</H1>
<br>
<p><strong>FOR HELP WITH AN IT ISSUE YOU ARE EXPERIENCING, PLEASE COMPLETE THE FORM BELOW
</strong> </p><br>
<br>
</br>

<textarea name="myTextBox" cols="100" rows="15" style="background-color:#FCF5D8;color:#AD8C08;">

Enter some text...
</textarea>

</br > 

</br > 
<H2>Category<H2/>
<select>
<option>Hardware</option>
<option>Software</option>
<option>networks</option>
<option>photocopier</option>
<option>printer</option>
<option>phones</option>
</select>


<H2>Department<H2/>  
<select>
<option>Computer science </option>
<option>Finance</option>
<option>Procurement</option>
<option>Medical</option>
<option>Library</option>
<option>Nursing</option>
</select>
</br > 
</br > 
</br > 

<input type="submit" />
</form>
