
    <?php  
    //session_start();//session starts here  
      
    ?>  
      
      
      
    <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
        
        <title>Login</title>  
    </head>  

      
    <body>  
      
     
    <div class="container">  
        <div class="row">  
            <div class="col-md-4 col-md-offset-4">  
                <div class="login-panel panel panel-success">  
                    <div class="panel-heading">  
                        <h3 class="panel-title">Sign In</h3>  
                    </div>  
                    <div class="panel-body">  
                        <form role="form" method="post" action="index.php">  
                            <fieldset>  
                                <div class="form-group"  >  
                                    <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>  
                                </div>  
                                <div class="form-group">  
                                    <input class="form-control" placeholder="Password" name="pass" type="password" value="">  
                                </div>  
      
      
                                    <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" onClick=" " >  
      
                                <!-- Change this to a button or input when using this as a form -->  
                              <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->  
                            </fieldset>  
                        </form>  
                    </div>  
                </div>  
            </div>  
        </div>  
    </div>  
      
      
    </body>  
      
    </html>  
      
    <?php  
      
    include("database/db_conection.php");  
      
    if(isset($_POST['login']))  
    {  
        $username=$_POST['email'];  
        $password=$_POST['pass'];  
      
        $check_user="select * from users WHERE username='$username'AND password='$password'";  
      
        $run=mysqli_query($dbcon,$check_user);  
      $_SESSION['email']=$_POST['email'];
        if(mysqli_num_rows($run))  
        {  
		//here session is used and value of $user_email store in $_SESSION.  
            echo "<script>window.open('indexx.php?user=$username','_self')</script>";  
      
            
      
        }  
        else  
        {  
          echo "<script>alert('Username or password is incorrect!')</script>";  
        }  
    }  
    ?>  
	
	