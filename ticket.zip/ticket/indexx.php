<?php

include("database/config.php");

    if(isset($_POST['sendticket']))
    {
        $username=$_GET['user'];
      $summary=$_POST['issue'];
      $category=$_POST['category'];
	  $department=$_POST['department'];
    $udate=date('d-m-Y h:i:s', time());;
   
       
     
    
	
	$sql="INSERT INTO oticket (summary,Category,Department,creator,timecreated)
VALUES
('$summary','$category','$department','$username','$udate')";

if (!mysql_query($sql,$connect))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	   $_SESSION['msg']="Ticket Submitted Successfully !!";
  }}
	
    ?>
	
	

<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml/DTD/xhtmli-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


<link href="css/menu.css" rel="stylesheet" type="text/css" />
<title>Admin Panel</title>

</head>
<body>
<div id="Holder">
<div id="header">
<h3 align="center" >Admin Panel</h3>
</div>
<div id="NavBar"><nav>
<ul>
<li><a href="tickets.php">home</a></li>
<li><a href="#">profile</a></li>
<li><a href="reg.php">register</a></li>
<li><a href="view_users.php">view users</a></li>
<li><a href="logout.php">Logout</a></li>

</ul>

</Nav>

</div>

<div id="PageHeading">
<br>
<div >
<br>
<p><strong><p style="color: red"><?php $username = htmlentities($_GET['user']); ?></p><br> 
</strong> </p><br>
</div>
	<div id="ContentLeft">
<form name="newticket" action="" method="post" id="newticket">

<?php  
          
if(isset($_POST['sendticket']))
	
{ ?>
											
<p style="color: red"><?php echo htmlentities($_SESSION['msg']); ?><?php echo htmlentities($_SESSION['msg']=""); ?></p>
                                            <?php } ?>

<br>
</br>


</form>
	</br>

		</h2>
	</div>
	<div id="ContentRight"></div>
<div id="Footer"></div>
</div>
</body>
</html>









