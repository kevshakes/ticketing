<?php

include("database/config.php");

    if(isset($_POST['sendticket']))
    {
        $username=$_GET['user'];
      $summary=$_POST['issue'];
      $category=$_POST['category'];
	  $department=$_POST['department'];
    $udate=date('d-m-Y h:i:s', time());;
   
       
     
    
	
	$sql="INSERT INTO fticket (summary,Category,Department,creator,timecreated)
VALUES
('$summary','$category','$department','$username','$udate')";

if (!mysql_query($sql,$connect))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	   $_SESSION['msg']="Ticket Submitted Successfully !!";
  }}
	
    ?>
	
	

<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml/DTD/xhtmli-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<title>Chuka University Support Portal</title>

</head>
<body>
<div id="Holder">
<div id="header">
<h3 align="center" >USER FEEDBACK FORM</h3>
</div>
<div id="NavBar"><nav>


</Nav>

</div>

<div id="PageHeading">
<br>
<div >
<br>
<p><strong><p style="color: red"><?php $username = htmlentities($_GET['user']); ?></p><br> 
</strong> </p><br>
</div>
	<div id="ContentLeft">
<form name="newticket" action="" method="post" id="newticket">

<?php  
          
if(isset($_POST['sendticket']))
	
{ ?>
											
<p style="color: red"><?php echo htmlentities($_SESSION['msg']); ?><?php echo htmlentities($_SESSION['msg']=""); ?></p>
                                            <?php } ?>

<br>
</br>

<textarea name="issue" id="issue" cols="100" rows="15" style="background-color:#FCF5D8;color:#AD8C08;" placeholder="Enter your issue here ..">

please write your feedback here....
</textarea>

</br > 

</br > 
<H4>Category<H4/>
<select name="category" id="category">
<option>Hardware</option>
<option>Software</option>
<option>networks</option>
<option>photocopier</option>
<option>printer</option>
<option>phones</option>
</select>


<H4>Department<H4/>  
<select name="department" id="department">
<option>Computer science </option>
<option>Finance</option>
<option>Procurement</option>
<option>Medical</option>
<option>Library</option>
<option>Nursing</option>
</select>
</br > 
</br > 
</br > 



<input type="submit" name="sendticket" id="sendticket" value="Submit Ticket" />
</form>
	</br>

		</h2>
	</div>
	<div id="ContentRight"></div>
<div id="Footer"></div>
</div>
</body>
</html>









