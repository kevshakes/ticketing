<?php session_start();
 $username=$_GET['user'];?>
 <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
        <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->  
        <link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/css/jasny-bootstrap.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js">

</script>
<script>
 

function setTicket(val,val2) {
$.ajax({
type: "POST",
url: "get_seater.php",
data:{'octicket': val,'ticket': val2},
success: function(data){
$("#ticket-assignment-status").html(data);
window.location.reload();
}
});
}

function getSeater(val,val2) {
$.ajax({
type: "POST",
url: "get_seater.php",
data:{'assignee': val,'ticket': val2},
success: function(data){
$("#ticket-assignment-status").html(data);
alert(data);
//$('#fpm').val(data);
}
});
}
</script>


	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
		<title>Chuka University ICT Support Portal - My Tickets</title>  
    </head>  
    <style>  
        .login-panel {  
            margin-top: 150px;  
        }  
        .table {  
            margin-top: 50px;  
      
        }  
      
    </style>  
      
    <body>  
      
    <div class="table-scrol">  
        <h1 align="center">MY TICKETS </h1>  
		<h3 align="center"><?php echo $username;?></h3>  
      
    <div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->  
	  
	
         <table id="tableId" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%" onClick="">

            <thead> 
            <tr>  		
				<th>Ticket Number </th>
                <th>Issue Summary</th>
				<th>Problem Category</th>
				<th>Department</th>
                <th>Staff Assigned </th>  
                <th>Affected User</th>  
                <th>Priority</th> 
				<th>Date Created</th>
                <th>Date Assigned</th>
				<th>Status</th>
            </tr>  
            </thead>  
			 <tbody data-link="row" class="rowlink">
      
            <?php 
include('database/pdoconfig.php');
$stmt = $DB_con->prepare("SELECT * FROM users WHERE username = :username");
$stmt->execute(array(':username' => $username));

 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {

		
				$id=$row['name']; }
		
$stmt = $DB_con->prepare("SELECT * FROM oticket WHERE assignee = :id");
$stmt->execute(array(':id' => $id));

 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {

		
				$ticketid=$row['ticketid'];
                $summary=$row['summary'];
				$category=$row['Category']; 
				$department=$row['Department']; 
                $assignee=$row['assignee'];  
                $creator=$row['creator'];  
                $priority=$row['priority'];
				$timecreated=$row['timecreated']; 
				$due=$row['due']; 
				$status=$row['status']; 
				?>
                
            <div id="<?php echo $ticketid; ?>" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" >
        <div class="modal-content">
          <div class="modal-header">
            <button type="button"  data-dismiss="modal"  onClick="<script> window.location.reload(); </script>"class="close"  aria-hidden="true">&times;</button>
            <h4 class="modal-title">Welcome to Helpdesk</h4>
          </div>
          <div class="modal-body">
            <p>
            <span id="ticket-assignment-status" style="color:green"  ></span> <br>
			<?php
			
				echo "<br>Ticket Number: ".$ticketid; 
			   echo "<br>"; 
               echo  "<br>Ticket Summary: ".$summary;
			   echo "<br>"; 
				echo "<br>Category: ".$category; 
				echo "<br>"; 
				echo " <br>Department: ".$department; 
				echo "<br>"; 
                echo "<br>Assigned To: ".$assignee; 
				echo "<br>"; 
                echo "<br>Created By: ".$creator; 
				echo "<br>"; 
                echo "<br>Priority: ".$priority; 
				echo "<br>";				
                echo '<br>Open/Close Ticket <select name="octicket" id="octicket"  onChange="setTicket(this.value,'; echo $ticketid; echo ');">
 <option>'; echo $status; echo '
</option><option>Open</option>
<option>Closed</option>

</select>  '; ?> <?php
				echo "<br>Time Created ".$timecreated; echo "<br>"; 
				echo "<br>Date Due ".$due; echo "<br>"; 
				
				?>

                time spent
                last activity
			</p>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
      <?php
      
            ?>  

			
    <!--here showing results in the table --> 
	<tr >
	<?php if($status=='Closed' || $status==''){?>
				<td id="ticketid"> <a href="#<?php echo $ticketid;?>" data-toggle="modal"> <?php echo $ticketid; ?></td> 
                <td><?php echo $summary;  ?></td> 
				<td><?php echo $category;  ?></td>
				<td><?php echo $department;  ?></td> 
                <td><?php echo $assignee;  ?></td>  
                <td><?php echo $creator;  ?></td>  
                <td><?php echo $priority;  ?></td>
				<td><?php echo $timecreated;  ?></td> 
                <td><?php echo $due;  ?></td> 
				<td><?php echo $status;  ?></td>				
                <!--btn btn-danger is a bootstrap button to show danger-->  
            </tr>  
      
            <?php } }?>  
       </tbody>
        </table> 
	
            </div>  
    </div>
    

	

	<!-- Loading Scripts -->
    <script type="text/javascript">
	$(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                $('#assignee').val( $('#assigned').val() );

            } 
            
        });
    });
</script>
    <script>
	
	function addRowHandlers() {
    var table = document.getElementById("tableId");
    var rows = table.getElementsByTagName("tr");
    for (i = 0; i < rows.length; i++) {
        var currentRow = table.rows[i];
        var createClickHandler = 
            function(row) 
            {
                return function() { 
                                        var cell = row.getElementsByTagName("td")[1];
                                        var id = cell.innerHTML;
                                        alert("id:" + id);
                                 };
            };

        currentRow.onclick = createClickHandler(currentRow);
    }
}

	</script>

	<script src="js/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jasny-bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>			
      
    </body>
      
     </html>   
      
     
   