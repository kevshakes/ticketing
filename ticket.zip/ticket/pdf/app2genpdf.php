<?php



require('fpdf.php');

//Connect to your database
include("../conection.php");

//Create new pdf file
$pdf=new FPDF();

//Disable automatic page break
$pdf->SetAutoPageBreak(false);

//Add first page
$pdf->AddPage();
//Set Header
$pdf->title = 'Uwezo Loan Application Portal - Group Business and Location Report';

		
$file='logo.png';
$link='logo.png';	
$file2='coat-of-arms.png';
$link2='coat-of-arms.png';	
//Put Image

		$pdf->Header($pdf->Image($file, $x=null, $y=null, $w=22, $h=22, $type='', $link=''));
//set initial y axis position per page
$pdf->Image($file, $x=80, $y=null, $w=224, $h=159, $type='', $link='');
$pdf->Image($file2, $x=150, $y=null, $w=0, $h=0, $type='', $link2='');
$y_axis = 50;

//Set Row Height
$row_height = 6;

//print column titles
$pdf->SetFillColor(232,232,232);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($y_axis);
$pdf->SetX(15);

$pdf->Cell(10,6,'Reg',1,0,'L',1);
$pdf->Cell(30,6,'Constituency',1,0,'L',1);
$pdf->Cell(20,6,'County',1,0,'L',1);
$pdf->Cell(20,6,'Ward',1,0,'L',1);
$pdf->Cell(25,6,'Location',1,0,'L',1);
$pdf->Cell(25,6,'SubLocation',1,0,'L',1);
$pdf->Cell(37,6,'ChiefAsstName',1,0,'L',1);
$pdf->Cell(30,6,'ChiefAsstMobile',1,0,'L',1);
$pdf->Cell(30,6,'BizArea',1,0,'L',1);
$pdf->Cell(30,6,'BizAreaName',1,0,'L',1);
$pdf->Cell(30,6,'NearestLandmarkType',1,0,'L',1);
$pdf->Cell(30,6,'NearestLandmarkName',1,0,'L',1);
$pdf->Cell(25,6,'StreetPlotNo',1,0,'L',1);
$pdf->Cell(30,6,'BizType',1,0,'L',1);
$pdf->Cell(20,6,'JointBiz',1,0,'L',1);


$y_axis = $y_axis + $row_height;

//Select the Products you want to show in your PDF file
$result= mysql_query("SELECT * FROM tblgroupbizloc ORDER BY GroupReg");

//initialize counter
$i = 0;

//Set maximum rows per page
$max = 25;



while($row2 = mysql_fetch_array($result))
{
	//If the current row is the last one, create new page and print column title
	if ($i == $max)
	{
		$pdf->AddPage();

		//print column titles for the current page
		$pdf->SetY($y_axis_initial);
		$pdf->SetX(15);

$pdf->Cell(10,6,'Reg',1,0,'L',1);
$pdf->Cell(30,6,'Constituency',1,0,'L',1);
$pdf->Cell(20,6,'County',1,0,'L',1);
$pdf->Cell(20,6,'Ward',1,0,'L',1);
$pdf->Cell(25,6,'Location',1,0,'L',1);
$pdf->Cell(25,6,'SubLocation',1,0,'L',1);
$pdf->Cell(37,6,'ChiefAsstName',1,0,'L',1);
$pdf->Cell(30,6,'ChiefAsstMobile',1,0,'L',1);
$pdf->Cell(30,6,'BizArea',1,0,'L',1);
$pdf->Cell(30,6,'BizAreaName',1,0,'L',1);
$pdf->Cell(30,6,'NearestLandmarkType',1,0,'L',1);
$pdf->Cell(30,6,'NearestLandmarkName',1,0,'L',1);
$pdf->Cell(25,6,'StreetPlotNo',1,0,'L',1);
$pdf->Cell(30,6,'BizType',1,0,'L',1);
$pdf->Cell(20,6,'JointBiz',1,0,'L',1);
		
		//Go to next row
		$y_axis = $y_axis + $row_height;
		
		//Set $i variable to 0 (first row)
		$i = 0;
	}


$reg =  $row2["GroupReg"];
$const =  $row2["GroupConstituency"];
$county = $row2["GroupCounty"];
$ward = $row2["GroupWard"];
$loc= $row2["GroupLocation"]; 
$subloc= $row2["GroupSubLocation"];
$chiefname=  $row2["GroupChiefAsstName"];
$chiefcell= $row2["GroupChiefAsstMobile"];
$bizar= $row2["BizArea"];
$bizarname= $row2["BizAreaName"];
$biznlmtype= $row2["BizNearstLandmarkType"];
$biznlmname= $row2["BizNearstLandmarkName"];
$bizstrtplotno= $row2["BizStreetPlotNo"];
$biztype= $row2["BizType"];
$jointbiz= $row2["JointBiz"];




	$pdf->SetY($y_axis);
	$pdf->SetX(15);
$pdf->Cell(10,6,$reg,1,0,'L',1);
$pdf->Cell(30,6,$const,1,0,'L',1);
$pdf->Cell(20,6,$county,1,0,'L',1);
$pdf->Cell(20,6,$ward,1,0,'L',1);
$pdf->Cell(25,6,$loc,1,0,'L',1);
$pdf->Cell(25,6,$subloc,1,0,'L',1);
$pdf->Cell(37,6,$chiefname,1,0,'L',1);
$pdf->Cell(30,6,$chiefcell,1,0,'L',1);
$pdf->Cell(30,6,$bizar,1,0,'L',1);
$pdf->Cell(30,6,$bizarname,1,0,'L',1);
$pdf->Cell(30,6,$biznlmtype,1,0,'L',1);
$pdf->Cell(30,6,$biznlmname,1,0,'L',1);
$pdf->Cell(25,6,$bizstrtplotno,1,0,'L',1);
$pdf->Cell(30,6,$biztype,1,0,'L',1);
$pdf->Cell(20,6,$jointbiz,1,0,'L',1);

	//Go to next row
	$y_axis = $y_axis + $row_height;
	$i = $i + 1;
}

mysql_close();

//Send file
$pdf->Output();
?>
