<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml/DTD/xhtmli-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<meta http-equiv="content-Type" content="text/html;charset"utf-8" />
<title>untitled document......</title>

</head>
<body>
<div id="Holder">
<div id="Header"></div>
<div id="NavBar"></div>
<div id="Content"></div>
<div id="Footer"></div>
</div>
</body>
</html>