<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="testdb";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>