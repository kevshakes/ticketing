
    <html>  
    <head lang="en">  
        <meta charset="UTF-8">  
        <link type="text/css" rel="stylesheet" href="bootstrap-3.2.0-dist\css\bootstrap.css"> <!--css file link in bootstrap folder-->  
        <title>View Users</title>  
    </head>  
    <style>  
        .login-panel {  
            margin-top: 150px;  
        }  
        .table {  
            margin-top: 150px;  
      
        }  
      
    </style>  
      
    <body>  
      
    <div class="table-scrol">  
        <h1 align="center">user account</h1>  
      
    <div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->  
      
      
        <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">  
            <thead>  
      
            <tr>  
      
                <th>Name</th>  
                <th>Email</th>  
                <th>Role</th>  
				 <th>Notifications</th>
				<th>Invite Date</th> 
               
                <th>Delete Account</th>  
            </tr>  
            </thead>  
      
            <?php  
            include("database/db_conection.php");  
            $view_users_query="select * from uaccount";//select query for viewing user account.  
            $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.  
      
            while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
            {  
                $name=$row[0];  
                $email=$row[1];  
				$role=$row[2];
				$notifications=$row[3];
                $invitedate=$row[4];  
                  
      
      
      
            ?>  
      
            <tr>  
    <!--here showing results in the table -->  
                <td><?php echo $name;  ?></td>  
                <td><?php echo $email;  ?></td> 
				<td><?php echo $role;  ?></td>
                <td><?php echo $notifications;  ?></td>  
                <td><?php echo $invitedate;  ?></td>  
                <td><a href="delete.php?del=<?php echo $user_id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
            </tr>  
      
            <?php } ?>  
      
        </table>  
            </div>  
    </div>  
      
      
    </body>  
      
    </html>  