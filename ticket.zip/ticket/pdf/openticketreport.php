<?php



require('fpdf.php');

//Connect to your database
include("../conection.php");

//Create new pdf file
$pdf=new FPDF();

//Disable automatic page break
$pdf->SetAutoPageBreak(false);

//Add first page
$pdf->AddPage();
//Set Header
$pdf->title = 'Chuka University ICT Support Portal';

		
$file='logo.png';
$link='logo.png';	
$file2='coat-of-arms.png';
$link2='coat-of-arms.png';	
//Put Image

		$pdf->Header($pdf->Image($file, $x=null, $y=null, $w=22, $h=22, $type='', $link=''));
//set initial y axis position per page
$pdf->Image($file, $x=80, $y=null, $w=224, $h=159, $type='', $link='');
//$pdf->Image($file2, $x=150, $y=null, $w=0, $h=0, $type='', $link2='');
$y_axis = 50;

//Set Row Height
$row_height = 6;

//print column titles
$pdf->SetFillColor(232,232,232);
$pdf->SetFont('Arial','B',12);
$pdf->SetY($y_axis);
$pdf->SetX(25);

$pdf->Cell(10,6,'ID',1,0,'L',1);
$pdf->Cell(30,6,'Summary',1,0,'L',1);
$pdf->Cell(30,6,'Category',1,0,'L',1);
$pdf->Cell(30,6,'Department',1,0,'L',1);
$pdf->Cell(30,6,'Assignee',1,0,'L',1);
$pdf->Cell(40,6,'Creator',1,0,'L',1);
$pdf->Cell(40,6,'Priority',1,0,'L',1);
$pdf->Cell(70,6,'Time Created',1,0,'L',1);
$pdf->Cell(60,6,'Due',1,0,'L',1);
$pdf->Cell(30,6,'Status',1,0,'L',1);


$y_axis = $y_axis + $row_height;

//Select the Products you want to show in your PDF file
$result= mysql_query("SELECT * FROM oticket where status='open' ORDER BY ticketid");

//initialize counter
$i = 0;

//Set maximum rows per page
$max = 25;



while($row = mysql_fetch_array($result))
{
	//If the current row is the last one, create new page and print column title
	if ($i == $max)
	{
		$pdf->AddPage();

		//print column titles for the current page
		$pdf->SetY($y_axis_initial);
		$pdf->SetX(25);

$pdf->Cell(10,6,'ID',1,0,'L',1);
$pdf->Cell(30,6,'Summary',1,0,'L',1);
$pdf->Cell(30,6,'Category',1,0,'L',1);
$pdf->Cell(30,6,'Department',1,0,'L',1);
$pdf->Cell(40,6,'Assignee',1,0,'L',1);
$pdf->Cell(40,6,'Creator',1,0,'L',1);
$pdf->Cell(40,6,'Priority',1,0,'L',1);
$pdf->Cell(70,6,'Time Created',1,0,'L',1);
$pdf->Cell(60,6,'Due',1,0,'L',1);
$pdf->Cell(30,6,'Status',1,0,'L',1);
		
		//Go to next row
		$y_axis = $y_axis + $row_height;
		
		//Set $i variable to 0 (first row)
		$i = 0;
	}


$tid =  $row["ticketid"];
$summary = $row["summary"];
$category = $row["Category"];
$dept = $row["Department"]; 
$assignee= $row["assignee"];
$creator=  $row["creator"];
$priority= $row["priority"];
$timecreated= $row["timecreated"];
$due= $row["due"];
$status = $row["status"];



	$pdf->SetY($y_axis);
	$pdf->SetX(25);
$pdf->Cell(10,6,$tid,1,0,'L',1);
$pdf->Cell(30,6,$summary,1,0,'L',1);
$pdf->Cell(30,6,$category,1,0,'L',1);
$pdf->Cell(30,6,$dept,1,0,'L',1);
$pdf->Cell(40,6,$assignee,1,0,'L',1);
$pdf->Cell(40,6,$creator,1,0,'L',1);
$pdf->Cell(40,6,$priority,1,0,'L',1);
$pdf->Cell(70,6,$timecreated,1,0,'L',1);
$pdf->Cell(60,6,$due,1,0,'L',1);
$pdf->Cell(30,6,$status,1,0,'L',1);

	//Go to next row
	$y_axis = $y_axis + $row_height;
	$i = $i + 1;
}

mysql_close();

//Send file
$pdf->Output();
?>
