<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml/DTD/xhtmli-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<meta http-equiv="content-Type" content="text/html;charset"utf-8" />
<title>untitled document......</title>

</head>
<body>
<div id="Holder">
<div id="header"></div>
<div id="NavBar"><nav>
<ul>
<li><a href="#">Login</a></li>
<li><a href="#">Register</a></li>
<li><a href="#">Forgot password</a></li>
</ul>

</Nav>

</div>
<div id="ContentLeft">
<div id="PageHeading">
<br>
<h1>page heading </h1>


	<div id="ContentLeft">
	<h2>Your message here<br>
	    Your message
	</br>

		</h2>
	</div>
	<div id="ContentRight"></div>
<div id="Footer"></div>
</div>
</body>
</html>




