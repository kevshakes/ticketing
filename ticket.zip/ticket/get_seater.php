<?php
session_start();
include('database/pdoconfig.php');
include("database/configs.php");
include("database/config.php"); 



if(!empty($_POST['assignee'])  ) 
{	

$id=$_POST['ticket'];
$assignee= $_POST['assignee'];
if ($_POST['assignee']=='Unassigned'){
	echo "Ticket Number". $id ." needs to be assigned. Try Again. "; 
	}
	else{
$sql="update oticket set assignee='$assignee' where ticketid='$id'";

if (!mysql_query($sql,$connect))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	   echo "Ticket Number". $id ." assigned successfully to "; 
  }
	

$stmt = $DB_con->prepare("SELECT * FROM oticket WHERE ticketid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php 
 if (isset($row['assignee'])){
 echo htmlentities($row['assignee']);
}
 else{
 echo htmlentities('No person assigned to the ticket');}
  ?>
  <?php
 }
}}

if(!empty($_POST['octicket'])  ) 
{	

$id=$_POST['ticket'];
$status= $_POST['octicket'];

$sql="update oticket set status='$status' where ticketid='$id'";

if (!mysql_query($sql,$connect))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	   echo "Ticket Number". $id ." successfully "; 
  }
	

$stmt = $DB_con->prepare("SELECT * FROM oticket WHERE ticketid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php 
 if (isset($row['status'])){
 echo htmlentities($row['status']);
}
 else{
 echo htmlentities('Ticket status not determined');}
  ?>
  <?php
 }
}

if(!empty($_POST['priority'])) 
{	
$id=$_POST['ticket'];
$priority= $_POST['priority'];
$sql="update oticket set priority='$priority' where ticketid='$id'";

if (!mysql_query($sql,$connect))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	   echo "Priority Successfully Set to"; 
	    
  }
	
    

//echo $assignee;
$stmt = $DB_con->prepare("SELECT * FROM oticket WHERE ticketid = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php 
 if (isset($row['priority'])){
 echo htmlentities($row['priority']); echo " for Ticket ".$id;}
 else{
 echo htmlentities('No priority set!');}
  ?>
  <?php
 }
}


?>