<form id='register' action='register.php' method='post'
accept-charset='UTF-8'>
<fieldset >
<legend>Register</legend>

<label for='username' >UserName:</label><br >
<input type='text' name='username' id='username' maxlength="50" />
<br >
<br >
<label for='password' >Password:</label><br >
<input type='password' name='password' id='password' maxlength="50" />
<br >
<br >
<input type='submit' name='Submit' value='Submit' />
</fieldset>
</form>